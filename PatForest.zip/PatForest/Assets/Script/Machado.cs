﻿using UnityEngine;
using System.Collections;

public class Machado : MonoBehaviour {

	public Renderer machado;

	public float speed=50f;

	public float velocity =5f;
	public float rotateVel=8f;

	public GameObject player;

	public bool right;

	// Use this for initialization
	void Start () {
		if (player.transform.rotation.y == 0)
			right = true;
		else
			right = false;

		machado = GetComponent<Renderer> ();
		//machado = GetComponent<Rigidbody2D> ();
		//machado.velocity = transform.right * speed;	
	}

	// Update is called once per frame
	void Update () {

		if (machado.isVisible == false) {
			Destroy (gameObject);
		}
		Quaternion rot = transform.rotation;
		transform.rotation = new Quaternion(0,0,0,0);


		if(right)
			transform.Translate (velocity*Time.deltaTime,0,0);
		else
			transform.Translate (-velocity*Time.deltaTime,0,0);
		
		transform.rotation = rot;
		transform.Rotate (new Vector3(0,0,-1), rotateVel);
	
	}


	void OnCollisionEnter2D(Collision2D collision){
		if(collision.gameObject.CompareTag("Cactos") || collision.gameObject.CompareTag("Ghost") ){
			Destroy (gameObject);
		}
	}
}
