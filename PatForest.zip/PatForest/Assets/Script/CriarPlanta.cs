﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CriarPlanta : MonoBehaviour {

	public List<Transform> posicoesPredefinidas;
	public GameObject treePrefab;



	// Use this for initialization
	void Start () {

		StartCoroutine (CriarPlantas());

	}
	
	// Update is called once per frame
	void Update () {
	
	}

	IEnumerator CriarPlantas(){

		while (true) {

			yield return new WaitForSeconds (2);

			Instantiate (treePrefab, posicoesPredefinidas [Random.Range(0, 6)].position, Quaternion.identity);
		
		}

	}

}
