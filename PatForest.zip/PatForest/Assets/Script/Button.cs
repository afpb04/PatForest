﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class Button : MonoBehaviour {

    Image img;
    RawImage a;
	// Use this for initialization
	void Start () {
        img = GetComponent<Image>();
        
	}
	
    
    void OnMouseEnter() {
        img.enabled = true;
        
    }

    void OnMouseExit(){
        img.enabled = false;

    }
    

}
