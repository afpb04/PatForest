﻿using UnityEngine;
using System.Collections;

public class TreePoison : MonoBehaviour {

	private float timeLife=10f;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		timeLife -= Time.deltaTime;
		if (timeLife < 0) {
			Destroy (gameObject);
		}
	
	}
}
