﻿using UnityEngine;
using System.Collections;

public class Cactos : MonoBehaviour {

	public float velocidade;
	public bool direcao;
	public float duracaoDirecao;
	private float tempoNaDirecao;
	public GameObject cactos;

	// Use this for initialization
	void Start () {

	}

	// Update is called once per frame
	void Update () {

		if (direcao)
		{
			transform.eulerAngles = new Vector2(0, 0);
		}
		else {
			transform.eulerAngles = new Vector2(0, 180);
		}
		transform.Translate(Vector2.right * velocidade * Time.deltaTime);

		tempoNaDirecao += Time.deltaTime;
		/*  if (tempoNaDirecao >= duracaoDirecao)
           {
               tempoNaDirecao = 0;
               direcao = !direcao;

           }
           */



	}
	void OnCollisionEnter2D(Collision2D collision){
		if(collision.gameObject.CompareTag("Machado")){
			Destroy (gameObject);
		}
	}
	void OnTriggerEnter2D()
	{
		tempoNaDirecao = 0;
		direcao = !direcao;
	}
}
