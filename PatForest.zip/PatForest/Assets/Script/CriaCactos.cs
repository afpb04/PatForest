﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CriaCactos : MonoBehaviour {

	public List <Transform> posicoesPredefinidas2;
	public GameObject Ghostprefab;



	// Use this for initialization
	void Start () {

		StartCoroutine (CriarPlantasCactos());

	}

	// Update is called once per frame
	void Update () {

	}

	IEnumerator CriarPlantasCactos(){

		while (true) {

			yield return new WaitForSeconds (5);

			Instantiate (Ghostprefab, posicoesPredefinidas2 [Random.Range(0, 3)].position, Quaternion.identity);

		}

	}

}
