﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Player : MonoBehaviour {

	// Use this for initialization
	public AudioSource audio;
	public List<AudioClip> clips;
	public float speed=2f;

	public GameObject heart1;
	public GameObject heart2;
	public GameObject heart3;



	public float jumpSpeed = 10f;

	public float speedTime;

	public bool speedNormal;

	public Rigidbody2D corpo;

	public Transform player;

	public Animator animator;

	public bool isGrounded;

	public float force=200f;

	public float jumpTime;

	public float jumpDelay = 0.2f;

	public bool jumped;

	public Transform ground;

	public int lifePlayer=3;

	public GameObject machado;

	public float velocity;

	public bool isCabeca;

	public float delayMachado = 0.5f;
	void Start () {

		animator = GetComponent<Animator> ();
	}

	// Update is called once per frame
	void Update () {

		Movimentar ();
		if(speedNormal==false && speed==1 && speedTime>0){
			speedTime -= Time.deltaTime;
			if (speedTime < 0) {
				speedNormal = true;
				speed = 2;
			}
		}
	}

	void Movimentar()
	{
		isGrounded = Physics2D.Linecast (this.transform.position,ground.position,1<<LayerMask.NameToLayer("Floor"));

		 isCabeca = Physics2D.Linecast (this.transform.position,ground.position,1<<LayerMask.NameToLayer("Cabeca"));


		animator.SetFloat ("run",Mathf.Abs(Input.GetAxis("Horizontal")));

		delayMachado -= Time.deltaTime;

		if(Input.GetButton("Fire1") && delayMachado < 0){
			//Instantiate (machado,transform.position, transform.rotation);
			GameObject m=Instantiate (machado,transform.position, transform.rotation) as GameObject;
			m.GetComponent<Machado> ().player=this.gameObject ;
			delayMachado = 0.5f;
			audio.clip = clips [1];
			audio.Play ();
		}
		if (Input.GetAxisRaw ("Horizontal")>0) {
			transform.Translate (Vector2.right * speed * Time.deltaTime);
			transform.eulerAngles = new Vector2(0,0);

		}


		if (Input.GetAxisRaw ("Horizontal")<0 ) {
			transform.Translate (Vector2.right * speed * Time.deltaTime);
			transform.eulerAngles = new Vector2(0,180);
		}

		if (Input.GetButtonDown ("Jump") && isGrounded && !jumped) {
			
			corpo.AddForce (transform.up*force);
			animator.SetTrigger ("jump");
			jumpTime = jumpDelay;
			jumped=true;
			audio.clip = clips [0];
			audio.Play ();

		}
		jumpTime -= Time.deltaTime;

		if(jumpTime<=0 && isGrounded && jumped){

			animator.SetTrigger("ground");
			jumped = false;
		}

	}





	void OnTriggerEnter2D(Collider2D other){

		if(other.gameObject.CompareTag("Poison")){

			Destroy (other.gameObject);
			speed = 1;
			speedTime = 5;
			speedNormal = false;
		}


		}


	void OnCollisionEnter2D(Collision2D collision){
		if (collision.gameObject.CompareTag ("Ghost") || collision.gameObject.CompareTag ("Cactos")) {
			lifePlayer -= 1;
			if (lifePlayer < 0) {
				Destroy (gameObject);
				Application.LoadLevel("gameover");
			}
			if (lifePlayer == 2) {
				Destroy (heart1);
			}
			if (lifePlayer == 1) {
				Destroy (heart2);
			}
			if (lifePlayer == 0) {
				Destroy (heart3);
			}
		}
		if (collision.gameObject.CompareTag ("Buraco")) {
			Destroy (gameObject);
		}


	}
}
