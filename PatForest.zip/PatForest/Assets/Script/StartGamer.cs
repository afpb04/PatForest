﻿using UnityEngine;
using System.Collections;

public class StartGamer : MonoBehaviour
{

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    public void iniciar()
    {



        Application.LoadLevel("Level1");




    }

}


