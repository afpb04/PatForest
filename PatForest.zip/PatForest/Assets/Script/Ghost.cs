﻿using UnityEngine;
using System.Collections;

public class Ghost : MonoBehaviour {

	public Transform target;
	public float speed = 0.02f;

	public float lifeTime=5f;

	// Use this for initialization
	void Start () {

	}
	void Update(){
	
		if (lifeTime < 0) {
			speed = 0.02f;

		} else {
			lifeTime -= Time.deltaTime;
		}
	}
	// Update is called once per frame
	void FixedUpdate () {


		target = GameObject.FindWithTag ("Player").transform;

		Vector3 forwardAxis = new Vector3 (0, 0, -1);

		transform.LookAt (target.position, forwardAxis);
		Debug.DrawLine (transform.position, target.position);
		//transform.eulerAngles = new Vector3 (0, 0, -transform.eulerAngles.z);
		transform.eulerAngles = new Vector3 (0, 0, 0);
		//transform.position -= transform.TransformDirection (Vector2.up) * speed ;
		float x = (50*speed * Time.deltaTime);
		float y = (50*speed * Time.deltaTime);
		if(transform.position.x > target.position.x)
			x = -x;
		if(transform.position.y > target.position.y)
			y = -y;

		if (x > 0 && transform.localPosition.x > 5.7f)
			x = 0;
		if (x < 0 && transform.localPosition.x < -5.7f)
			x = 0;

		if (transform.position.x > target.position.x) {
			transform.eulerAngles = new Vector2(0,0);	
			transform.Translate (x, y, 0);
		}

		if (transform.position.x < target.position.x) {
			transform.eulerAngles = new Vector2(0,180);	
			transform.Translate (-x, y, 0);}


	}
	void OnCollisionEnter2D(Collision2D collision){
		if (collision.gameObject.CompareTag ("Machado")) {

			hitme ();


			}
		}

	void hitme(){
		speed = 0.01f;
		lifeTime = 5f;
	}
	}


	
